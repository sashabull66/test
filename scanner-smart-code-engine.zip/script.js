window.WorkerLogger = {
  initWorkerLogger() {
    if (!window.workerLog) {
      window.workerLog = [];
    }
  },
  LogInfo(data) {
    window?.workerLog?.push(data);
  },
};

// Worker vars:
let worker;
const invalidResultHistory = new Set();
// Initial значение типа сессии
let globalDoctype = "barcode";
// Типы сессий
const cessionTypes = ["barcode", "phone", "card", "universalPay"];
const activatorSelectorEnum = {
  firstSession: "firstSession",
  secondSession: "secondSession",
};
let currentActivatedSession = activatorSelectorEnum["firstSession"];
let tempUploadedImage = "";
const activatedSessions = new Map();

// Типы result.payload
const SCAN_RESULT_TYPES = {
  phone: "PHONE",
  qr: "QR_CODE",
  card: "CARD",
  requisites: "REQUISITES",
};

// Worker utils:

// Останавливает и удаляет текущий worker
const killWorker = () => {
  if (!worker) {
    return;
  }
  worker.onmessage = null;
  worker?.terminate();
  worker = undefined;
  activatedSessions.clear();
};

// Преобразует строку base64 в byteArray (только в таком виде SE принимает изображения для распознавания)
const convertToByteArray = (base64str) =>
  Uint8Array.from(atob(base64str), (c) => c.charCodeAt(0));

// Преобразует base64str в byteArray и отправляет в worker, может пометить текущее изображение флагом isManuallyUploaded
const loadFile = (base64str, isManuallyUploaded = false) => {
  try {
    const byteArray = convertToByteArray(base64str);

    worker?.postMessage({
      isManuallyUploaded,
      requestType: "file",
      imageData: byteArray.buffer,
    });
  } catch (e) {
    console.error(e);
  }
};

// Для картинок из стрима камеры
const loadImage = (base64str) => {
  tempUploadedImage = "";
  window?.WorkerLogger?.LogInfo?.({ info: "Вызов loadImage" });
  loadFile(base64str, false);
};

// Для ручной загрузки
const uploadPhoto = (base64str) => {
  tempUploadedImage = base64str;
  window?.WorkerLogger?.LogInfo?.({ info: "Вызов uploadPhoto" });
  loadFile(base64str, true);
};

// Отправляет message в window.workerLog, в виде postMessage и в webkit
const postMessageToWebkit = (message) => {
  if (window?.isDevEnv) {
    window?.WorkerLogger?.LogInfo?.({
      info: "Отправка сообщения в webkit",
      payload: message,
    });
    postMessage(message);
  }
  if (window?.webkit?.messageHandlers?.callbackHandler?.postMessage) {
    window.webkit.messageHandlers.callbackHandler.postMessage(message);
  }
};

// Создает сессию инстанса SE с указанным docType
const createSession = (docType) => {
  worker?.postMessage({
    requestType: "createSession",
    data: docType,
  });
};

// Отправляет код активации для инстанса SE
const activate = (code) => {
  worker?.postMessage({
    requestType: "activationCode",
    session: currentActivatedSession,
    code,
  });
};

/**
 * Декодирует строку из Base64 с автоопределением кодировки (UTF-8 / Windows-1251)
 * **/
const decodeBase64String = (encodedString) => {
  const binaryData = atob(encodedString);

  const bytes = new Uint8Array(binaryData.length);

  for (let i = 0; i < binaryData.length; i++) {
    bytes[i] = binaryData.charCodeAt(i);
  }

  const utf8String = new TextDecoder("utf-8").decode(bytes);

  const reEncoded = new TextEncoder().encode(utf8String);

  if (reEncoded.length !== bytes.length) {
    try {
      return new TextDecoder("windows-1251").decode(bytes);
    } catch (e) {
      return utf8String;
    }
  }

  return utf8String;
};

const checkAlfaSign = (string) => {
  const prefixes = ["aid", "alfabank"];

  return prefixes.some((prefix) => string.startsWith(prefix));
};

// Утилиты для преобразования валидного ответа либы в формат нужный для отправки в smart-camera-api
const convertQrResult = (result, isManuallyUploaded = false) => {
  if (result?.URL?.value_string) {
    if (result.URL.isAccepted === true) {
      // QR с признаками AlfaSign
      const isHasAlfaSign = checkAlfaSign(result.URL.value_string);

      // QR с признаками AlfaSign распознанный после ручной загрузки
      const isHasAlfaSignAfterManualUploading =
        isHasAlfaSign && isManuallyUploaded;

      // Если QR с признаками AlfaSign распознанный после ручной загрузки, то обязательно нужно отдать ответ
      if (isHasAlfaSignAfterManualUploading) {
        window?.WorkerLogger?.LogInfo?.({
          info: "Произошло распознавание QR с признаками AlfaSign после ручной загрузки.",
        });
        return [];
        // Если QR с признаками AlfaSign распознанный со стрима, ничего не отдаем и рестартуем сессию
      } else if (isHasAlfaSign) {
        window?.WorkerLogger?.LogInfo?.({
          info: "Произошло распознавание QR с признаками AlfaSign. Производится рестарт worker",
        });
        initSmartCodeEngine(globalDoctype);
      } else {
        return {
          type: SCAN_RESULT_TYPES.qr,
          scanData: result.URL.value_string,
        };
      }
    }
  }
  if (result?.bytes?.value_binary) {
    if (result.bytes.isAccepted === true) {
      const decodedResult = decodeBase64String(result.bytes.value_binary);

      // QR с признаками AlfaSign
      const isHasAlfaSign = checkAlfaSign(decodedResult);

      // QR с признаками AlfaSign распознанный после ручной загрузки
      const isHasAlfaSignAfterManualUploading =
        isHasAlfaSign && isManuallyUploaded;

      // Если QR с признаками AlfaSign распознанный после ручной загрузки, то обязательно нужно отдать ответ
      if (isHasAlfaSignAfterManualUploading) {
        window?.WorkerLogger?.LogInfo?.({
          info: "Произошло распознавание QR с признаками AlfaSign после ручной загрузки.",
        });
        return [];
        // Если QR с признаками AlfaSign распознанный со стрима, ничего не отдаем и рестартуем сессию
      } else if (isHasAlfaSign) {
        window?.WorkerLogger?.LogInfo?.({
          info: "Произошло распознавание QR с признаками AlfaSign. Производится рестарт worker",
        });
        initSmartCodeEngine(globalDoctype);
      } else {
        return {
          type: SCAN_RESULT_TYPES.qr,
          scanData: decodedResult,
        };
      }
    }
  }
};

// Утилита мутирующая ответ для сессии не universalPay. Мутирует ответ только когда распознанный результат имеет тип MatrixBarcode.
// Ложит в result.value.value_string декодированное значение от result.value.value_binary.
const convertQrResultToQrScanner = (result) => {
  const [firstElement, ...rest] = result?.data;

  if (firstElement.type !== "MatrixBarcode") {
    return result;
  }

  const value_string = firstElement.bytes?.value_binary
    ? decodeBase64String(firstElement.bytes.value_binary)
    : firstElement.value.value_string;

  const modifiedElement = {
    ...firstElement,
    value: { ...firstElement.value, value_string },
  };

  return [modifiedElement, ...rest];
};

const convertTelNumberResult = (result) => {
  if (result?.phone_number?.isAccepted === true) {
    return {
      type: SCAN_RESULT_TYPES.phone,
      scanData: result?.phone_number?.value_string,
    };
  }
};
/**
 * Удаляет пробелы из номера карты. Из номера 1234 1234 1234 1234 получается строка 1234123412341234
 * */
const joinCardNumber = (splittedCardNumber) =>
  splittedCardNumber.replace(/ /g, "");

const convertBankCardResult = (result) => {
  if (result?.number?.isAccepted === true) {
    return {
      type: SCAN_RESULT_TYPES.card,
      scanData: joinCardNumber(result?.number?.value_string),
    };
  }
};
const convertPaymentsDetailsResult = (result) => {
  let barcode = "ST00012";

  if (result?.kpp?.isAccepted === true) {
    barcode += `|KPP=${result?.kpp?.value_string}`;
  }

  if (result?.inn?.isAccepted === true) {
    barcode += `|PayeeINN=${result?.inn?.value_string}`;
  }

  if (result?.rcbic?.isAccepted === true) {
    barcode += `|BIC=${result?.rcbic?.value_string}`;
  }

  if (result?.rus_bank_account?.isAccepted === true) {
    barcode += `|PersonalAcc=${result?.rus_bank_account?.value_string}`;
  }

  if (barcode.length > 7) {
    return {
      scanData: barcode,
      type: SCAN_RESULT_TYPES.qr,
    };
  }
};

const convertResult = (result, isManuallyUploaded = false) => {
  const [firstElement] = result?.data;
  switch (firstElement.type) {
    case "BankCard":
      return convertBankCardResult(firstElement);

    case "CodeTextLine":
      return convertTelNumberResult(firstElement);

    case "MatrixBarcode":
      return convertQrResult(firstElement, isManuallyUploaded);

    case "PaymentDetails":
      return convertPaymentsDetailsResult(firstElement);
  }
};

/**
 * 1. Инициализирует лог в window.workerLog
 * 2. Задает doctype в глобальную переменную (нужно при реактивации)
 * 3. Останавливает и удаляет потенциально уже созданный ранее worker в window.worker
 * 4. Создает в window.worker новый worker и запускает в нем инстанс SE
 * 5. Навешивает на ранее созданный worker слушатель его сообщений
 * @param doctype 'barcode' | 'phone' | 'card' | 'universalPay'
 * */
const initSmartCodeEngine = (doctype) => {
  window?.WorkerLogger?.initWorkerLogger?.();

  if (doctype) {
    globalDoctype = doctype;
  }

  killWorker();

  window?.markActiveBtn?.(globalDoctype);

  const initSmartCodeEngineWorker = (type) => {
    window?.WorkerLogger?.LogInfo?.({
      info: `Выполнение createSession с аргументом ${type}`,
    });

    if (cessionTypes.includes(type)) {
      worker = new Worker("./smart-code/worker.js");
    } else {
      return;
    }

    worker.onmessage = async (msg) => {
      const resultData = msg.data;
      switch (resultData?.requestType) {
        case "wasmEvent": {
          if (resultData.data.type === "ready") {
            window?.WorkerLogger?.LogInfo?.({
              info: `wasmEvent c статусом ready. Производится создание сессии с типом ${type}`,
            });
            createSession(type);
          }
          if (["error", "processError"].includes(resultData.data.type)) {
            window?.WorkerLogger?.LogInfo?.({
              error: `wasmEvent c ошибкой: ${resultData.data.type}. Производится рестарт worker`,
            });

            initSmartCodeEngine(globalDoctype);
          }
          break;
        }

        case "result": {
          if (
            resultData.isManuallyUploaded &&
            Object.keys(resultData.data).length === 0
          ) {
            invalidResultHistory?.add?.(resultData.session);
            window?.WorkerLogger?.LogInfo?.({
              info: `Получен невалидный result после ручной загрузки от ${resultData.session}`,
            });

            const result = JSON.stringify({
              type: "scannerResult",
              status: "result",
              payload: [],
            });

            if (
              globalDoctype === "universalPay" &&
              invalidResultHistory.size === 2
            ) {
              window?.WorkerLogger?.LogInfo?.({
                info: "Получен невалидный result после ручной загрузки от двух сессий",
              });
              invalidResultHistory?.clear?.();
              tempUploadedImage = "";
              postMessageToWebkit(result);
            } else if (globalDoctype !== "universalPay") {
              window?.WorkerLogger?.LogInfo?.({
                info: "Получен невалидный result после ручной загрузки",
              });
              tempUploadedImage = "";
              postMessageToWebkit(result);
            }
          }

          if (resultData.data.length) {
            let result;

            if (globalDoctype === "universalPay") {
              // Тут будет либо ответ, либо undefined
              const convertedPayload = convertResult(
                resultData,
                resultData?.isManuallyUploaded,
              );

              // Кейс для qr c AlfaSign
              if (!convertedPayload) {
                break;
              }

              result = JSON.stringify({
                type: "scannerResult",
                status: "result",
                payload: convertedPayload,
              });
            } else {
              result = JSON.stringify({
                type: "scannerResult",
                status: "result",
                payload: convertQrResultToQrScanner(resultData),
              });
            }

            tempUploadedImage = "";
            postMessageToWebkit(result);

            window?.WorkerLogger?.LogInfo?.({
              info: "Получен успешный result c payload. Производится рестарт worker",
              result,
            });
            initSmartCodeEngine(globalDoctype);
          }

          break;
        }

        case "activated": {
          const activationResult = JSON.stringify({
            type: "scannerResult",
            status: "activationSuccessful",
            payload: null,
          });
          window?.applyPositiveCssStyles?.(globalDoctype);

          postMessageToWebkit(activationResult);

          activatedSessions.set(
            currentActivatedSession,
            currentActivatedSession,
          );

          if (
            tempUploadedImage &&
            ((activatedSessions.size === 2 &&
              globalDoctype === "universalPay") ||
              (activatedSessions.size === 1 &&
                globalDoctype !== "universalPay"))
          ) {
            window?.WorkerLogger?.LogInfo?.({
              info: "Отправка ранее сохраненного изображения",
            });
            loadFile(tempUploadedImage, true);
            tempUploadedImage = "";
          }

          break;
        }

        case "activation":
        case "secondSessionActivation": {
          currentActivatedSession = activatorSelectorEnum[resultData?.session];

          activatedSessions.delete(currentActivatedSession);

          const activationResult = JSON.stringify({
            type: "scannerResult",
            status: "activationExpired",
            payload: resultData?.code,
          });
          postMessageToWebkit(activationResult);
          window?.applyNegativeCssStyles?.(resultData?.code);
          window
            ?.activateLibrary?.(resultData?.code)
            ?.then((data) => activate(data.code));

          break;
        }

        default:
          break;
      }
    };
  };

  switch (globalDoctype) {
    case "barcode":
      initSmartCodeEngineWorker("barcode");
      break;
    case "phone":
      initSmartCodeEngineWorker("phone");
      break;
    case "card":
      initSmartCodeEngineWorker("card");
      break;
    case "universalPay":
      initSmartCodeEngineWorker("universalPay");
      break;
    default:
      window?.WorkerLogger?.LogInfo?.({
        error: `Неверно указан docType. Ожидается 'barcode' | 'phone' | 'card' | 'universalPay' а передан '${globalDoctype}'`,
      });
      break;
  }
};

// Интерфейс для взаимодействия для IOS AM приложения
window.scanner = {
  createSession: initSmartCodeEngine,
  uploadPhoto,
  loadImage,
  activate,
};
